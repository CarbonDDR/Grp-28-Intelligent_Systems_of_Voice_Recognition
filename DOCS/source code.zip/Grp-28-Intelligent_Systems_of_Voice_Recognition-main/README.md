# Grp 28 Intelligent Systems of Voice Recognition
A desktop application that will perform the task given by the end-user through voice command. This project aims to ease and fasten the process for the end-user and therefore make life simpler

Contribution:

Naman Dave (201801439): System Architect, core(‘s) developer, Added functionality; Tell Joke, Math String Evaluator, Wolfram Alpha API (nmn)
Core : (Recommendation System, Intent extractor (recombyte), VA functionalities (va), Data Hashing, storage, loader, and Inverse Hashing(recombyte).

Nishit Jagetia(201801027): 
1) Constantly arranging meetings and interacting with the group members related to the project stuff and lab submissions.
2) Contributed in a significant amount in this project report and lab reports.
3) Added functions and a dictionary of words related to open Visual Studio Code Application through Voice Command on different platforms (MacOS, Linux, Windows).
4) Added functions and dictionary of words related to open Eclipse Application on voice command on the above platforms.

Aakash Panchal(201801459): Added two functionalities:
1) Given a file-name with extension, search it on the whole pc.
2) Given a folder name, find the folder.
Both searches are case-insensitive and this features will be extended as follows:
If more than one files exist with similar names, then let the user choose which one he/she wants to open, over voice command.

Jeet Umat(201801232):added given functionality
1)open the default downloads folders of desktop according to the system
2)generate a strong password of length given by user 
3)give the information about remaining battery
4)give information about total cores of cpu,usage of cores(in percentage),maximum and minimum frequency of cpu
5)give information about partition of disk 
6)give the information about total memory data of a computer
7)give our current location in google map

Divyansh Khatri(201801012): Added Given Functionality
1) Added Functions to Open or start Google Chrome on all three platforms
2) Added Functions to Search directly on Wikipedia (on google chrome) about some topic.
3) Added Function to know the current date and time through voice command.

Jay Shah(201801141):
1) Open Mozilla Firefox through the Voice Command on all three platforms.

Parthav Kansagra(201801145):
1) Open webex meeting through the voice Command 
2) Open stopwatch through the voice command

Manali Reddy(201801118):
1) Creation and deletion of files in different format (.txt, .pdf, etc.) specified by the user

Siddharth Moradiya (201801470):
1) Added a functionality to play any music or video from a given folder path in offline mode. First the user provides the folder path and then the system shows the list of files which is available on that folder. after the user says file number and the system will play that particular music/video for the user.
2) Contributed in all the labs discussion, report making..

Kishan Gadhiya(201801147):
Open notepad in windows through the voice command
Open Gedit in linux through the voice command
